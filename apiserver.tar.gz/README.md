# apiserver

#### 项目介绍
nvc项目接口服务端

#### 软件架构
软件架构说明：使用beego框架搭建的api服务

#### 操作说明
启动服务:bee run -gendoc=true -downdoc=true